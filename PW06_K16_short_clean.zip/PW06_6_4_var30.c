#include <stdio.h>

int main(void)
{
    int copies, tier1 = 0, tier2 = 0, tier3 = 0;
    double price;

    printf("Тираж книги: ");
    if (scanf("%d", &copies) != 1 || copies <= 0) {
        puts("Некорректный тираж");
        return 0;
    }
    printf("Цена одного экземпляра: ");
    if (scanf("%lf", &price) != 1 || price <= 0) {
        puts("Некорректная цена");
        return 0;
    }

    if (copies <= 10000) {
        tier1 = copies;
    } else if (copies <= 50000) {
        tier1 = 10000;
        tier2 = copies - 10000;
    } else {
        tier1 = 10000;
        tier2 = 40000;
        tier3 = copies - 50000;
    }

    double r1 = tier1 * price * 0.10;
    double r2 = tier2 * price * 0.12;
    double r3 = tier3 * price * 0.15;
    printf("Тираж: %d, цена: %.2f\n", copies, price);
    printf("10%%: %d экз., роялти %.2f\n", tier1, r1);
    printf("12%%: %d экз., роялти %.2f\n", tier2, r2);
    printf("15%%: %d экз., роялти %.2f\n", tier3, r3);
    printf("Итого: %.2f\n", r1 + r2 + r3);
    return 0;
}
