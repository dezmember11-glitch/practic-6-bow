#include <stdio.h>

int main(void)
{
    int number, count1 = 0, count2 = 0;
    long long sum1 = 0, sum2 = 0;

    printf("Введите целые числа (0 — конец ввода):\n");
    while (scanf("%d", &number) == 1 && number != 0) {
        long long triangle = 0;
        int k = 1;
        while (triangle < number) triangle += k++;

        if (number > 0 && triangle == number) {
            count1++;
            sum1 += number;
        } else {
            count2++;
            sum2 += number;
        }
    }

    printf("Треугольных чисел: %d\n", count1);
    if (count1) printf("Среднее: %.2f\n", (double)sum1 / count1);
    else puts("Среднее: нет чисел");

    printf("Остальных чисел: %d\n", count2);
    if (count2) printf("Среднее: %.2f\n", (double)sum2 / count2);
    else puts("Среднее: нет чисел");
    return 0;
}
