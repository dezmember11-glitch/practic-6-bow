#include <stdio.h>

void clear_input(void)
{
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF) {}
}

int main(void)
{
    const double pi = 3.141592653589793;
    int choice;
    double x, y = 0, volume;

    while (1) {
        puts("\n1. Сфера\n2. Куб\n3. Цилиндр\n4. Конус\n5. Выход");
        printf("Выберите пункт: ");
        if (scanf("%d", &choice) != 1) {
            if (feof(stdin)) break;
            clear_input();
            puts("Некорректный ввод");
            continue;
        }
        if (choice == 5) break;

        switch (choice) {
            case 1: printf("Радиус сферы: "); break;
            case 2: printf("Сторона куба: "); break;
            case 3: printf("Радиус и высота цилиндра: "); break;
            case 4: printf("Радиус и высота конуса: "); break;
            default: puts("Нет такого пункта"); continue;
        }

        int ok;
        if (choice <= 2) ok = scanf("%lf", &x) == 1 && x > 0;
        else ok = scanf("%lf %lf", &x, &y) == 2 && x > 0 && y > 0;
        if (!ok) {
            if (feof(stdin)) break;
            clear_input();
            puts("Размеры должны быть положительными числами");
            continue;
        }

        switch (choice) {
            case 1: volume = 4.0 * pi * x * x * x / 3.0; break;
            case 2: volume = x * x * x; break;
            case 3: volume = pi * x * x * y; break;
            case 4: volume = pi * x * x * y / 3.0; break;
            default: continue;
        }
        printf("Объем: %.3f\n", volume);
    }
    return 0;
}
