/* Задание 6.3, вариант 24. */
#include <stdio.h>

int main(void)
{
    int number;
    unsigned long count1 = 0, count2 = 0;
    double sum1 = 0.0, sum2 = 0.0;

    printf("Введите целые числа (0 - конец ввода):\n");

    while (scanf("%d", &number) == 1 && number != 0) {
        long long triangle = 0;
        int next = 1;

        while (triangle < number) {
            triangle += next;
            next++;
        }

        if (number > 0 && triangle == number) {
            count1++;
            sum1 += number;
        } else {
            count2++;
            sum2 += number;
        }
    }

    printf("Треугольные числа: %lu\n", count1);
    if (count1 > 0) {
        printf("Среднее: %.2f\n", sum1 / count1);
    } else {
        printf("Среднее не определено: группа пуста.\n");
    }

    printf("Остальные числа: %lu\n", count2);
    if (count2 > 0) {
        printf("Среднее: %.2f\n", sum2 / count2);
    } else {
        printf("Среднее не определено: группа пуста.\n");
    }

    return 0;
}
