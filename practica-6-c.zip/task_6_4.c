/* Задание 6.4, вариант 30. */
#include <stdio.h>

int main(void)
{
    int copies;
    double part1, part2, part3;
    double royalty1, royalty2, royalty3, total;

    printf("Введите тираж книги (целое неотрицательное число): ");
    if (scanf("%d", &copies) != 1 || copies < 0) {
        printf("Ошибка: нужен целый неотрицательный тираж.\n");
        return 0;
    }

    if (copies <= 10000) {
        part1 = copies;
        part2 = 0.0;
        part3 = 0.0;
    } else if (copies <= 50000) {
        part1 = 10000.0;
        part2 = copies - 10000.0;
        part3 = 0.0;
    } else {
        part1 = 10000.0;
        part2 = 40000.0;
        part3 = copies - 50000.0;
    }

    royalty1 = part1 * 0.10;
    royalty2 = part2 * 0.12;
    royalty3 = part3 * 0.15;
    total = royalty1 + royalty2 + royalty3;

    printf("Тираж: %d\n", copies);
    printf("До 10000:           %.0f * 10%% = %.2f\n", part1, royalty1);
    printf("От 10000 до 50000:  %.0f * 12%% = %.2f\n", part2, royalty2);
    printf("Свыше 50000:        %.0f * 15%% = %.2f\n", part3, royalty3);
    printf("Итого роялти: %.2f усл. ед.\n", total);

    return 0;
}
