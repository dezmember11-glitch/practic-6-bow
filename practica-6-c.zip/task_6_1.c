/* Задание 6.1, вариант 26. */
#include <stdio.h>
#include <ctype.h>

int main(void)
{
    int ch;
    int previous = 0;
    unsigned long count = 0;
    unsigned long printable_count = 0;

    printf("Введите ASCII-текст, в конце поставьте #:\n");

    while ((ch = getchar()) != EOF && ch != '#') {
        if (previous == '\\') {
            count++;

            if (isprint((unsigned char)ch)) {
                printable_count++;
            }
        }

        previous = ch;
    }

    printf("Экранированных символов: %lu\n", count);
    printf("Из них печатных: %lu\n", printable_count);

    return 0;
}
