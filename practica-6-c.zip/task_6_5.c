/* Задание 6.5, вариант 4. */
#include <stdio.h>
#include <math.h>
#include <string.h>

int read_line(char *line, int size)
{
    int ch;

    if (fgets(line, size, stdin) == NULL) {
        return 0;
    }
    if (strchr(line, '\n') == NULL && !feof(stdin)) {
        while ((ch = getchar()) != '\n' && ch != EOF) {

        }
        line[0] = '\0';
    }
    return 1;
}

int read_length(const char *prompt, double *value)
{
    char line[128];
    char extra;

    printf("%s", prompt);
    if (!read_line(line, sizeof line)) {
        return 0;
    }

    if (sscanf(line, "%lf %c", value, &extra) != 1 ||
        !isfinite(*value) || *value <= 0.0) {
        printf("Ошибка: введите положительное число, дробная часть через точку.\n");
        return 0;
    }
    return 1;
}

int main(void)
{
    const double pi = 3.141592653589793;
    char line[128];
    char extra;
    int choice;
    int running = 1;
    double radius, side, height, volume;

    while (running) {
        printf("\n1 - Шар (сфера)\n2 - Куб\n3 - Цилиндр\n4 - Конус\n0 - Выход\n");
        printf("Выберите пункт: ");

        if (!read_line(line, sizeof line)) {
            break;
        }
        if (sscanf(line, "%d %c", &choice, &extra) != 1) {
            printf("Ошибка: введите целый номер пункта.\n");
            continue;
        }

        switch (choice) {
            case 1:
                if (!read_length("Радиус: ", &radius)) {
                    continue;
                }
                volume = (4.0 / 3.0) * pi * radius * radius * radius;
                break;

            case 2:
                if (!read_length("Сторона куба: ", &side)) {
                    continue;
                }
                volume = side * side * side;
                break;

            case 3:
                if (!read_length("Радиус: ", &radius) ||
                    !read_length("Высота: ", &height)) {
                    continue;
                }
                volume = pi * radius * radius * height;
                break;

            case 4:
                if (!read_length("Радиус: ", &radius) ||
                    !read_length("Высота: ", &height)) {
                    continue;
                }
                volume = pi * radius * radius * height / 3.0;
                break;

            case 0:
                running = 0;
                printf("Работа завершена.\n");
                break;

            default:
                printf("Ошибка: выберите пункт от 0 до 4.\n");
                continue;
        }

        if (running) {
            if (isfinite(volume)) {
                printf("Объем: %.6f куб. ед.\n", volume);
            } else {
                printf("Ошибка: размеры слишком велики для расчета.\n");
            }
        }
    }

    return 0;
}
