/* Задание 6.2, вариант 18. */
#include <stdio.h>
#include <wchar.h>
#include <locale.h>

#ifdef _WIN32
#include <fcntl.h>
#include <io.h>
#endif

int main(void)
{
    wint_t ch;
    unsigned long replacements = 0;

    setlocale(LC_ALL, "");

#ifdef _WIN32

    if (_setmode(_fileno(stdin), _O_U8TEXT) == -1 ||
        _setmode(_fileno(stdout), _O_U8TEXT) == -1) {
        return 1;
    }
#endif

    wprintf(L"Введите текст, в конце поставьте #:\n");
    wprintf(L"Результат замены:\n");

    while ((ch = getwchar()) != WEOF && ch != L'#') {
        if (ch == L'о') {
            ch = L'0';
            replacements++;
        }
        putwchar((wchar_t)ch);
    }

    wprintf(L"\nКоличество замен: %lu\n", replacements);

    return 0;
}
