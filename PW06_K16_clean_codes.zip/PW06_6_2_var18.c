#include <stdio.h>
#include <wchar.h>
#include <locale.h>

int main(void)
{
    wint_t ch;
    int count = 0;

    setlocale(LC_ALL, "");

    wprintf(L"Введите текст (завершите символом #):\n");
    wprintf(L"Результат замены: ");

    while ((ch = getwchar()) != WEOF && ch != L'#') {
        if (ch == L'о') {
            ch = L'0';
            count++;
        }
        putwchar((wchar_t)ch);
    }

    wprintf(L"\nКоличество замен 'о' на '0': %d\n", count);
    return 0;
}
