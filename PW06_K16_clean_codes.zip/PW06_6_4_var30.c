#include <stdio.h>

int main(void)
{
    int copies;
    int tier1 = 0, tier2 = 0, tier3 = 0;
    double price, royalty1, royalty2, royalty3, total;

    printf("Введите тираж книги (экземпляров): ");
    if (scanf("%d", &copies) != 1 || copies <= 0) {
        printf("Ошибка: тираж должен быть положительным целым числом.\n");
        return 0;
    }

    printf("Введите цену одного экземпляра (руб.): ");
    if (scanf("%lf", &price) != 1 || price <= 0) {
        printf("Ошибка: цена должна быть положительным числом.\n");
        return 0;
    }

    if (copies <= 10000) {
        tier1 = copies;
    } else if (copies <= 50000) {
        tier1 = 10000;
        tier2 = copies - 10000;
    } else {
        tier1 = 10000;
        tier2 = 40000;
        tier3 = copies - 50000;
    }

    royalty1 = tier1 * price * 0.10;
    royalty2 = tier2 * price * 0.12;
    royalty3 = tier3 * price * 0.15;
    total = royalty1 + royalty2 + royalty3;

    printf("\nИсходный тираж: %d экз.\n", copies);
    printf("Цена экземпляра: %.2f руб.\n", price);
    printf("Первая ступень (10%%): %d экз., роялти %.2f руб.\n", tier1, royalty1);
    printf("Вторая ступень (12%%): %d экз., роялти %.2f руб.\n", tier2, royalty2);
    printf("Третья ступень (15%%): %d экз., роялти %.2f руб.\n", tier3, royalty3);
    printf("Итоговое роялти: %.2f руб.\n", total);

    return 0;
}
