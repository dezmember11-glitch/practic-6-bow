#include <stdio.h>
#include <ctype.h>

int main(void)
{
    int ch;
    int escaped = 0;
    int count = 0;
    int printable = 0;

    printf("Введите ASCII-текст (завершите символом #):\n");

    while ((ch = getchar()) != EOF && ch != '#') {
        if (escaped) {
            count++;
            if (isprint((unsigned char)ch)) {
                printable++;
            }
            escaped = 0;
        } else if (ch == '\\') {
            escaped = 1;
        }
    }

    printf("Количество экранированных символов: %d\n", count);
    printf("Из них печатных: %d\n", printable);
    return 0;
}
