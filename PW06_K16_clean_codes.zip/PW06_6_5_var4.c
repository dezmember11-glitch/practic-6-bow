#include <stdio.h>

void clear_input(void)
{
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF) {

    }
}

int main(void)
{
    const double pi = 3.141592653589793;
    int choice = 0;
    double r, h, a, volume;

    while (choice != 5) {
        printf("\n--- КАЛЬКУЛЯТОР ОБЪЕМА ---\n");
        printf("1. Объем сферы\n");
        printf("2. Объем куба\n");
        printf("3. Объем цилиндра\n");
        printf("4. Объем конуса\n");
        printf("5. Выход\n");
        printf("Выберите пункт: ");

        if (scanf("%d", &choice) != 1) {
            if (feof(stdin)) {
                break;
            }
            clear_input();
            printf("Ошибка: введите номер пункта от 1 до 5.\n");
            continue;
        }

        switch (choice) {
            case 1:
                printf("Введите радиус сферы: ");
                if (scanf("%lf", &r) != 1 || r <= 0) {
                    printf("Ошибка: радиус должен быть положительным.\n");
                    clear_input();
                    continue;
                }
                volume = (4.0 / 3.0) * pi * r * r * r;
                printf("Объем сферы: %.3f\n", volume);
                break;

            case 2:
                printf("Введите сторону куба: ");
                if (scanf("%lf", &a) != 1 || a <= 0) {
                    printf("Ошибка: сторона должна быть положительной.\n");
                    clear_input();
                    continue;
                }
                volume = a * a * a;
                printf("Объем куба: %.3f\n", volume);
                break;

            case 3:
                printf("Введите радиус и высоту цилиндра: ");
                if (scanf("%lf %lf", &r, &h) != 2 || r <= 0 || h <= 0) {
                    printf("Ошибка: радиус и высота должны быть положительными.\n");
                    clear_input();
                    continue;
                }
                volume = pi * r * r * h;
                printf("Объем цилиндра: %.3f\n", volume);
                break;

            case 4:
                printf("Введите радиус и высоту конуса: ");
                if (scanf("%lf %lf", &r, &h) != 2 || r <= 0 || h <= 0) {
                    printf("Ошибка: радиус и высота должны быть положительными.\n");
                    clear_input();
                    continue;
                }
                volume = pi * r * r * h / 3.0;
                printf("Объем конуса: %.3f\n", volume);
                break;

            case 5:
                printf("Завершение работы.\n");
                break;

            default:
                printf("Ошибка: выберите пункт от 1 до 5.\n");
                continue;
        }
    }

    return 0;
}
