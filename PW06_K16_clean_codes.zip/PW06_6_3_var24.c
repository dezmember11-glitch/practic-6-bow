#include <stdio.h>

int main(void)
{
    int number;
    int count1 = 0, count2 = 0;
    long long sum1 = 0, sum2 = 0;

    printf("Введите целые числа (0 завершает ввод):\n");

    while (scanf("%d", &number) == 1 && number != 0) {
        long long triangle = 0;
        long long k = 1;

        while (triangle < number) {
            triangle += k;
            k++;
        }

        if (number > 0 && triangle == number) {
            count1++;
            sum1 += number;
        } else {
            count2++;
            sum2 += number;
        }
    }

    printf("Треугольные числа: %d\n", count1);
    if (count1 > 0) {
        printf("Их среднее: %.2f\n", (double)sum1 / count1);
    } else {
        printf("Их среднее: нет чисел\n");
    }

    printf("Остальные числа: %d\n", count2);
    if (count2 > 0) {
        printf("Их среднее: %.2f\n", (double)sum2 / count2);
    } else {
        printf("Их среднее: нет чисел\n");
    }

    return 0;
}
